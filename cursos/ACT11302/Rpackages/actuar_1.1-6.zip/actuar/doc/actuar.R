### R code from vignette source 'actuar.Rnw'
### Encoding: ISO8859-1

###################################################
### code chunk number 1: actuar.Rnw:78-79 (eval = FALSE)
###################################################
## vignette(package = "actuar")


###################################################
### code chunk number 2: actuar.Rnw:82-83 (eval = FALSE)
###################################################
## demo(package = "actuar")


###################################################
### code chunk number 3: actuar.Rnw:98-99 (eval = FALSE)
###################################################
## citation()


###################################################
### code chunk number 4: actuar.Rnw:102-103 (eval = FALSE)
###################################################
## citation("actuar")


